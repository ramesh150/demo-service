package com.contact.service;

import com.contact.entity.User;

public interface UserService {

    public User getUser(Long id);
}
